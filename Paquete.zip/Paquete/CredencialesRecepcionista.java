package Paquete;

public interface CredencialesRecepcionista {
    String USUARIO = "Recep02";
    String CONTRASENA = "98765";

    String NombreRecep = "Renzo", ApellidoRecep = "Bendezu", rolRecep = "R";
    int dniRecep = 70987654;
}
