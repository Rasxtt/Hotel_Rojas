package Paquete;

public interface CredencialesAdmin {
    String USUARIO = "Admin13";
    String CONTRASENA = "12345";

    String NombreAdmin = "Diego", ApellidoAdmin = "Chuquiure", rolAdmin = "A";
    int dniAdmin = 70456789;
}
